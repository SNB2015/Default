#!/usr/bin/bash
tla=$1
env=$2
app_name=$3

for foo in `/opt/tnt/bin/tlatool -t $tla | /usr/bin/tr " " "\n"`
do
    /opt/tnt/bin/hostinfo -F -c $foo| /bin/grep -i $env | /usr/bin/awk -F'|' /$3/'{print $1$9}';
done