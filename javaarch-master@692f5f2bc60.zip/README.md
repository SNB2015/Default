# JavaArch 12 Configuration VM Base Playbook

This playbook takes cares JavaArch 12 Configuration

```Note: playbook should run with SA/root privileges```

#### Supported OS

| Distribution     | Version
| :------------- | :--------|
 | **RedHat** | **7.x** |

### Steps to Execute playbook

#### Ansible AWX/Tower
To Run the playbook over Ansible AWX/Tower follow the Document.

[JavaArch12_Runbook_Ansible](https://ntrs.sharepoint.com/:w:/s/ITServiceDeliveryAutomation/EVBHjJEsY9RFleRz7wXDhksB0DBr-gbqGRgu8mucSIWiBA?e=0DggTA)

#### Ansible CLI
To Run the playbook over AWX CLI follow the below table.

#### Mandatory Extra Variables

| Extra vars     | Purpose
| :------------- | :--------|
| **env: sys/int/dry/prod/uat/staging** | *Playbook will deploy on selected environment* |
| **dc: wpc/npc** | *Playbook will deploy on selected datacenter* |
| **deploy_zone: appzone/internal** | *Choose app server resides on* |
| **tla: xxx** | *Playbook will use TLA to validate the host information* |
| **execution_option: configuration/decommission** | *Playbook to configure and decom the application* |
| **type_of_task: setup_base_env/TLA_Setup or All** | *Choose the type of task to execute* |
| **app_grp: cxxx** | *Define the WebLogic group to setup application TLA* |
| **managed_dir_count: 1** | *Define the number value to create managed directory under runtime for uat,prod,dry and staging ENV* |


  **sample output**
  ```
  SSH password:
  BECOME password[defaults to SSH password]:
  PLAY [Build the Linux VM Base Environment for JavaArch12] **********************
  TASK [setup] *******************************************************************
  ok: [ut14609]
```
