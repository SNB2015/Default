# Deployments
- Activate your UCP-Dev client bundle.
  - ```cd ucp-client-bundle && eval "$(<env.sh)"```
- Create the Docker DTR login for the repository that hosts the target images
  - ```python create_image_pull_secret.py <namespace> -o pull_secret.yml && kubectl apply -f pull_secret.yml```
- Apply deployment configuration in *configuration/&lt;app instance&gt;-vars.yml* and
  deployment secrets in *configuration/&lt;app instance&gt;-secrets.yml*
- Run the *create_resources.yml* playbook to place secrets into the secrets/
  directory, and places deployment files into deployments/
  - ```ansible-playbook create_resources.yml -e app_instance="<app_instance>"```
- Create the Kubernetes secrets using the data in secrets/
  - ```python apply_secrets.py <namespace> secrets/```
- Create the Kubernetes AWX application using the data in deployments/
  - ```kubectl apply -f deployment/```
- Subsequent deployments will not need to use secrets/ again so it is safe to delete the directory.
  - ```rm -rf secrets/```

# Getting command line access to the Kubernetes cluster
Follow the instructions on the Docker EMS Sharepoint site
http://sharepoint2013.ntrs.com/sites/EnterpriseMiddlewareServices/Shared%20Documents1/Docker%20DCaaS/DCaaS%20Kubernetes%20Guide.pdf

# Using the ServiceAccount
The ServiceAccount lets the awx-rabbit container probe the
Kubernetes API to autodiscover other awx-rabbit containers in its namespace. This enables the auto-clustering feature of AWX.  

### Kubernetes 1.11+

Kubernetes 1.11 supports RBAC via yml files, so the deployment files should contain all the setup necessary to create a successful deployment and reading this section is not required.

### Kubernetes 1.8

If the Kubernetes deployment environment is 1.8, it does not support native Kubernetes RBAC but we can still get the same functionality from Docker UCP by creating UCP Roles and Grants and assigning them to the ServiceAccount we are using. To do so, you will need to ask the Docker EMS team to create a Role in the target Docker environment called "uxa-endpoint-reader" and create a Grant to grant the awx ServiceAccount that role. The operations the uxa-endpoint-reader Role requires are:

** Kubernetes Endpoint Operations **
- Kubernetes Endpoint Get
- Kubernetes Endpoint List
- Kubernets Endpoint Watch

** Kubernetes Endpoint/status Operations **
- Kubernetes Endpoint/status Get
- Kubernetes Endpoint/status List
- Kubernetes Endpoint/status Watch

Do not delete the ServiceAccount after it has been assigned a grant. Deleting it also deletes its Grant

# Using images in Docker Trusted Registry
Each container in the deployment spec references an image that is in DTR. To pull these images, the Kubernetes deployment must be able to authenticate to and pull these images. Authentication is done by creating an Secret object of type kubernetes.io/dockercfg and assigning that to the ServiceAccount "awx".

### Create or update a secret to pull images from Docker Trusted Registry
```python create_pull_secret.py -o pull_secret.yml && kubectl apply -f pull_secret.yml ```
