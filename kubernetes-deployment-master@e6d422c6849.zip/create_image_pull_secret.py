#!/usr/bin/env python2

import getpass
import argparse
import base64
import os

KUBERNETES_SECRET_FILE = """---
kind: Secret
apiVersion: v1
type: kubernetes.io/dockercfg
metadata:
  creationTimestamp: null
  name: docker-dtr-login
  namespace: {}
data:
  .dockercfg: {}"""


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("namespace", help='The target Kubernetes namespace')
    parser.add_argument("-f", "--filename", help="File that contains a "
                        "username, password, email, and docker_registry, all "
                        "on seperate lines")
    parser.add_argument("-o", "--output", help="File where the Kubernetes "
                        "credential will be stored. If not provided, the "
                        "credential will be displayed to stdout. Create the "
                        "secret by doing 'kubectl apply -f <output file>'")
    return parser.parse_args()


def parse_file_for_credentials(filename):
    if not os.path.exists(filename):
        raise SystemExit("Error: File {} not found".format(filename))

    with open(filename, "rb") as credential_file:
        try:
            username = credential_file.readline().strip()
            password = credential_file.readline().strip()
            email = credential_file.readline().strip()
            docker_registry = credential_file.readline().strip()
        except ValueError:
            raise SystemExit("Error: Credentials in file {} are in invalid "
                             "format".format(filename))

        if not email or not username or not password or not docker_registry:
            raise SystemExit("Error: Credentials in file {} are in invalid "
                             "format".format(filename))

    return username, password, email, docker_registry


def prompt_user_for_credentials():
    username = raw_input("Username: ")
    password = getpass.getpass()
    email = raw_input("Email: ")
    docker_registry = raw_input("DTR address [docker-dtr-dev.ntrs.com]: ") or \
        "docker-dtr-dev.ntrs.com"
    return username, password, email, docker_registry


def format_credentials(username, password, email, docker_registry):
    template = '{{"{}":{{"username":"{}","password":"{}","email":"{}","auth":"{}"}}}}'
    base64_cred = base64.b64encode(username + ":" + password)
    return base64.b64encode(template.format(docker_registry, username,
                                            password, email, base64_cred))


def create_kubernetes_secret(namespace, credential):
    return KUBERNETES_SECRET_FILE.format(namespace, credential)


def main():
    args = get_args()
    if args.filename:
        username, password, email, docker_registry = \
            parse_file_for_credentials(args.filename)
    else:
        username, password, email, docker_registry = \
            prompt_user_for_credentials()

    credential = format_credentials(username, password, email, docker_registry)
    secret = create_kubernetes_secret(args.namespace, credential)

    if args.output:
        open(args.output, "w").write(secret)
    else:
        print secret


if __name__ == "__main__":
    main()
