#!/usr/bin/env python2

import os
import subprocess
import argparse

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("namespace", help='The target Kubernetes namespace')
    parser.add_argument("secrets_dir", help='Path to the directory that ' +
        'contains the secrets to be created')
    return parser.parse_args()

def main():
    args = get_args()
    if not os.path.exists(args.secrets_dir):
        raise SystemExit(args.secrets_dir + " does not exist")

    # kubectl create secret generic awx-secrets -n uxa-dev --from-file secrets/
    subprocess.call(["kubectl", "create", "secret", "generic", "awx-secrets",
        "-n", args.namespace, "--from-file", args.secrets_dir])

if __name__ == '__main__':
    main()
