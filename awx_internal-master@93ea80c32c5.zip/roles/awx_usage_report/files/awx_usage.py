#! /usr/bin/python
#############################################################
#                                                           #
#               !!! AWX Usage Report !!!                    #
#               ========================                    #
#         Python script :                                   #
#            1. Connects to AWX instance (Dev/UAT/Prod)     #
#            2. Collects usage data                         #
#            3. Prepare CSV report                          #
#                                                           #
#############################################################

import requests
import json
import time
import sys
import csv
import datetime
import getpass
import os
from os import path

def parse_date_time(s):
    date = ""
    time = ""
    if s != None:
        datetime = s.split('T')
        date = datetime[0]
        time = datetime[1]
        temp = time.split('.')
        time = temp[0]
    return date + " " + time


def generate_auth_token(username, password, env):
    tokenURL = AWX_HOST_URL + "/api/v2/tokens/"
    print(tokenURL)
    time.sleep(5)
    data = {
    "description": "My Access Token",
    "application": 1,
    "scope": "read"
    }

    headers = { 'Content-Type': 'application/json' }

    # Get token
    response = requests.post(tokenURL, 
        verify=False, auth=(username, password))

    parsed = json.loads(response.text)
    print(json.dumps(parsed, indent=4, sort_keys=True))

    for key, value in parsed.items():
        print(key, ":", value)

    print(parsed["token"])

    oauth2_token_value = parsed["token"]
    return oauth2_token_value

print(len(sys.argv))

if len(sys.argv) != 5:
    print ("Usage: python awx_usage.py <env> <awx_admin_user> <awx_admin_password> <path_to_store_report>")
    sys.exit(0)

env = sys.argv[1].lower()
user = sys.argv[2]
passwd = sys.argv[3]
filename = sys.argv[4]

if env == "dev":
   AWX_HOST_URL = "https://uxa.ksd.ntrs.com"
elif env == "uat":
   AWX_HOST_URL = "https://uxa.ksu.ntrs.com"
elif env == "prod":
   AWX_HOST_URL = "https://uxa.ks.ntrs.com"
else:
   print("Invalid ENV. Possible values are dev, uat or prod")
   sys.exit(0)

oauth2_token_value = generate_auth_token(user, passwd, env)

print("Auth token is = " + oauth2_token_value)

nextURL = '/api/v2/jobs/'
url = AWX_HOST_URL + nextURL
payload = {}
headers = {'Authorization': 'Bearer ' + oauth2_token_value,}

x = datetime.datetime.now()

#filename = "C:\\Temp\\AWXUsageReport-" + env + x.strftime("%m-%d-%Y-%H%M%S") + ".csv"
#filename = "/home/home02/hvs2-sa/" + env + x.strftime("%m-%d-%Y-%H%M%S") + ".csv"
#filename = report_path + "/" + env + x.strftime("%m-%d-%Y-%H%M%S") + ".csv"
print(filename)
if not os.path.exists(filename):
    os.mknod(filename)
file1 = open(filename,"w") 

while nextURL != None:
    # makes request to Tower user endpoint
    response = requests.request('GET', url, headers=headers, data=payload, allow_redirects=False, verify=False)
    y = response.json();
    if nextURL != None:
        for x in (y['results']):
            #print(x['name'], parse_date_time(x['started']), parse_date_time(x['finished']))
            s = x['name'] + "," + parse_date_time(x['started']) + "," + parse_date_time(x['finished']) + "\n"
            file1.write(s)
    
    nextURL = y['next'] 
    if nextURL != None:
        url = str(AWX_HOST_URL + nextURL)
    print("Sleeping for 15 seconds")
    time.sleep(15)

print("Exiting")
file1.close()
