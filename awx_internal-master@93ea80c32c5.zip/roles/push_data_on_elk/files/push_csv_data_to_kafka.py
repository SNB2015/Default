#!/usr/bin/python
# 
# Plugin to push static data from CSV to Kafka Topic
# (c) 2022 Northern Operating Solutions
# (c) Platform Engineering Team
# 
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

import json
import os 
import re
from kafka import KafkaProducer
from kafka.errors import KafkaError
import sys
import getpass
from findCostMapping import getTotalCost
import datetime

DOCUMENTATION = '''

    Script Name: push_csv_data_to_kafka.py

    requirements:
         - python3
         - CSV data with first row as field names

    description: 
         - This Python script:
                - Accepts some inputs from user
                - Reads data from CSV file
                - Prepares message for each data record from CSV
                  in the format accepted by Kafka
                - Push all those messages to Kafka Topic
           The pushed messages are can be consumed by consumer which can be further used to display on dashboard (Kibana/PowerBI)

    inputs:
         - CSV data file path
         - Environment
         - Kafka Topic Name
         - If higher environment then:
               - CA Cert Path
               - SSL Cert Path
               - SSL Private Key Path
               - Password to decrypt the SSL Key

    output:
         Customized JSON object to push to Kafka
'''

try:
    from __main__ import cli
except ImportError:
    cli = None

# Define default variables
script_name = sys.argv[0]
caRootLocation = ""
ssl_cert = " "
ssl_key = " "
passwd = " "
KAFKA_BOOTSTRAP_SERVERS = [ 'lnadkfe0022.ntrs.com:9094', 'lnadkfe0024.ntrs.com:9094', 'lnadkfe0026.ntrs.com:9094']
higher_envs = [ "uat", "prod" ]
lower_envs = [ "dev", "int", "sys" ]
env_list = lower_envs
env_list.extend(higher_envs)
kafka_topic = "nt_elk_pag_filebeat"
today = datetime.datetime.now()
default_ts = ""+today.isoformat()+"Z"

# Accept User inputs:
#  - Absolute path to CSV data file
#  - Envrionment (dev/uat/prod)
#  - Kafka Topic name
#  - 
#input_records_file = str(input("Enter the absolute path to CSV file: ") or " ")
input_records_file = sys.argv[1]
ldap_user = sys.argv[2]
ldap_pass = sys.argv[3]
env = sys.argv[4]

#env = str(input("Enter environment[dev]: ") or "dev").lower()
if env not in env_list:
    print("Incorrect ENV value entered")
    sys.exit(-1)

#kafka_topic = str(input("Enter Kafka Topic [nt_elk_pag_filebeat]: ") or "nt_elk_pag_filebeat")

# Accept Cert inputs from user if env is higher
if "UAT_SSL_certificate" in os.environ:
    caRootLocation = os.environ.get("CA_ROOT_certificate")
    ssl_cert = os.environ.get("UAT_SSL_certificate")
    ssl_key = os.environ.get("UAT_SSL_key")
    passwd = os.environ.get("UAT_key_password")
if "PROD_SSL_CERTIFICATE" in os.environ:
    caRootLocation = os.environ.get("CA_ROOT_CERTIFICATE")
    ssl_cert = os.environ.get("PROD_SSL_CERTIFICATE")
    ssl_key = os.environ.get("PROD_SSL_KEY")
    passwd = os.environ.get("PROD_KEY_PASSWORD")

# Set Kafka Brokers
if env == "uat":
    KAFKA_BOOTSTRAP_SERVERS = [ 'lnaukfe0002.ntrs.com:9092', 'lnaukfe0004.ntrs.com:9092', 'lnaukfe0006.ntrs.com:9092', 'lnaukfe0001.ntrs.com:9092', 'lnaukfe0003.ntrs.com:9092', 'lnaukfe0005.ntrs.com:9092' ]
elif env == "prod":
    KAFKA_BOOTSTRAP_SERVERS = [ 'lnapkfe0002.ntrs.com:9092', 'lnapkfe0004.ntrs.com:9092', 'lnapkfe0006.ntrs.com:9092', 'lnapkfe0008.ntrs.com:9092', 'lnapkfe0007.ntrs.com:9092', 'lnapkfe0009.ntrs.com:9092', 'lnapkfe0011.ntrs.com:9092', 'lnapkfe0013.ntrs.com:9092' ]

# Check for csv file validation

format_ext = os.path.splitext(input_records_file)[-1].lower()
print(" The format is "+ format_ext)
if format_ext == ".csv":
    print("---------------")
    print("valid csv file")
    print("---------------")
else:
    print("---------------")
    print("Invalid csv file \nStopping the execution...")
    print("---------------")
    exit()

# Check if we are executing the automation on which operating system
if os.name!="nt":
    print("Executing the dos2unix command")
    cmd ="dos2unix {}".format(input_records_file)

# Open File in read mode and read all lines into a list
file_pointer = open(input_records_file, 'r')
csv_data_records = file_pointer.readlines()

# Save toil_hours field index
toil_index = csv_data_records[0].rstrip().split(',').index("toil_hrs_saved")

# Check if the toil hours feild is present
# If not reject the csv

for item in csv_data_records:
    try:
        toil_rec = item.strip().split(',')[toil_index]
        if not toil_rec:
            raise Exception("Toil Hours not present, Rejecting the input csv file")
    except IndexError:
            pass

# Store all field names and number of fields
fields_record = csv_data_records[0].rstrip().split(',')
number_of_fields = len(fields_record)

#Initialize counter to start read from line 1
line_num = 1

#Iterate over all the lines of CSV file starting first record
while line_num < len(csv_data_records):

    #Initialize Empty Record
    dict_record = {}
    
    #Read current record from CSV file into list
    data_record = csv_data_records[line_num].rstrip().split(',')
    
    #Length of current data record
    record_length = len(data_record)
    
    #Iterate over all the field values in current record
    #and store into a message format, accepted by Kafka Topic
    field_itretor = 0
    while field_itretor < record_length:

        #Grab field name from field record
        field = fields_record[field_itretor]
                
        #Store field and its corresponding value
        dict_record[field] = data_record[field_itretor]

	# Replace with default time if start feild is missing        
        if field == "start" and dict_record[field] == "":
            dict_record[field] = default_ts

	# Replace with default time if end field is missing
        if field == "end" and dict_record[field] == "":
            dict_record[field] = default_ts
 
	# Replace with No Value if any field is missing other than toil_hours
        if dict_record[field] == "":
            dict_record[field] = "No Value"

	# Adding the total cost saved field
        if field == "toil_hrs_saved":
           dict_record["total_cost_saved"] = float(getTotalCost(dict_record["user_id"], dict_record["toil_hrs_saved"], ldap_user, ldap_pass))

        #Increament iterator to read next field data
        field_itretor += 1

    #In case of some last missing values in current record,
    #fill thsoe values with "No Value" string
    if record_length < number_of_fields:
        while field_itretor < number_of_fields:
            field = fields_record[field_itretor]
            dict_record[field] = "No Value"
           
            #Increament iterator to read next field data
            field_itretor += 1

    #Increament iterator to read next data record
    line_num += 1
    
    #Convert message to Json object
    json_dump = json.dumps(dict_record)
    Kafka_message = json.loads(json_dump)
    print(dict_record)
    try:
        #Define producer obejct to push messages to Kafka topic
        # Push a toil savings detials to Kafka topic
        if env in  higher_envs:
            producer = KafkaProducer(bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS, security_protocol='SSL', ssl_check_hostname=False, ssl_cafile=caRootLocation, ssl_certfile=ssl_cert, ssl_keyfile=ssl_key, ssl_password=passwd)
            producer.send(kafka_topic, json_dump.encode('utf-8') )
        elif env in lower_envs:
            producer = KafkaProducer(bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS, value_serializer=lambda x: json.dumps(x).encode('utf-8'))
            producer.send(kafka_topic, Kafka_message)
        producer.flush()
        producer.close()       
    except KafkaError as ke:
        print("Issue with message send to Kafka Error -> %s" % ke)

print("Total " + str(line_num-1) + " Messages Sent to Kafka")
