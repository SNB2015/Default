#!/usr/bin/python
# 
# Python script to find out actual cost savings
# (c) 2022 Northern Operating Solutions
# (c) Platform Engineering Team
# 

import json
import os 
import re
import sys
import getpass
import ldap3
from ldap3 import Server, Connection, ALL, NTLM

DOCUMENTATION = '''

    Script Name: findCostMapping.py

    requirements:
         - python3

    description: 
         - This Python script:
                - Accepts some inputs from user
                - Calculates total cost savings for a user based on number of toil hours saved  

    inputs:
         - user id or lan id 
         - toil hours saved
         - ldap user
         - ldap password

    output:
         - Total cost savings for a user
'''

# Define variables
DEFAULT_COST = "50"
CONTRACTOR_INDEX = 0
FTE_INDEX = 1
region_cost_mapping = { "NA": [ "106", "97" ], "MEX": [ "98", "98" ], "EMEA": [ "103", "86" ], "APAC": [ "25", "20" ], "DEFAULT": [ "50", "50" ] }

# Function to calculate the total cost savings for a user
def getTotalCost(user_id, toil_hours, ldap_user, ldap_password):
 
    # Nested function to connect to Active directory to get the user properties
    def get_properties(lan_id):
        try:
            server = Server('ad.ntrs.com', get_info=ALL, use_ssl=True)
            conn = Connection(server, user="ENT\\" + str(ldap_user), password=ldap_password, authentication=NTLM, auto_bind=True)
            conn.search('DC=ent,DC=ad,DC=ntrs,DC=com', '(&(objectclass=user)(samaccountname={}))'.format(lan_id), attributes=['memberof', 'title'])
            return conn.entries[0]
        except Exception as e:
              return "ad_error"

    # Nested function to get region of the user
    def get_region(groups): 
        region = "DEFAULT"
        valid_regions = [ "NA", "APAC", "EMEA" ]
        for valid_region in valid_regions:
          region_group = "IDM-Region-" + valid_region
          if(re.search(region_group, str(groups))):
              region = valid_region              
        if(region == "NA" and re.search("IDM-Country-MX", str(groups))):
              region = "MEX"
        return region

    # Nested function to get cost based on title of the user
    def get_cost(region, title):
        if(title == "Contractor"):
          return region_cost_mapping[region][CONTRACTOR_INDEX]
        return region_cost_mapping[region][FTE_INDEX]

    user_properties = get_properties(user_id)
    cost_savings = DEFAULT_COST
    if(user_properties != "ad_error"):
        user_region = get_region(user_properties.memberof)
        user_title = user_properties.title
        cost_savings = get_cost(user_region, user_title)
    return float(cost_savings) * float(toil_hours)
