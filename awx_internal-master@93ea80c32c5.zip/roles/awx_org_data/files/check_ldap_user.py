#!/usr/bin/python

####################################
#    !!! "check_ldap_user.py" !!!  #  
#                                  # 
#  Inputs:                         #
#   - ldap user                    #
#   - ldap user's password         #
#   - lan id of awx user           #
#                                  #
#  Function:                       #
#    This python script is used to # 
#    check if an awx user is active#
#    in Active Directory           #
#                                  #
####################################

# Import required python modules

import sys
import ldap3
from ldap3 import Server, Connection, ALL, NTLM

# Method to check awx user info in Active Directory

def get_properties(ldap_user,ldap_password,lan_id):
    """
     Method to check awx user info in active directory 
     
     Parameters
     ---------
       ldap_user: str 
         ldap user to connect to active directory
       ldap_password: str 
         ldap user's password
       lan_id: str
         awx user's lan id
     Returns
     -------
       str 
    """
    try:
        lanid = lan_id.split('@')[0] 
        server = Server('ad.ntrs.com', get_info=ALL, use_ssl=True)
        conn = Connection(server, user="ENT\\" + str(ldap_user), password=ldap_password, authentication=NTLM, auto_bind=True)
        conn.search('DC=ent,DC=ad,DC=ntrs,DC=com', '(&(objectclass=user)(samaccountname={}))'.format(lanid), attributes=['title'])
        return conn.entries[0]
    except Exception as e:
          return e

# Below are the inputs to the python script

user_login = sys.argv[1]
user_passwd = sys.argv[2]
user_id = sys.argv[3]

# Call the method get_properties and store return value in a variable

user_status = get_properties(user_login, user_passwd, user_id)

# print user id

print(user_id)

# print user status 

print(user_status)
