##########################################################
#							 #
#    !!! Python script to create Excel workbook !!!      #
# 						         #		 
#  Function:                                             #
#     - This script creates an excel workbook fromi      #
#       CSV files  					 #	
#                                                        #
##########################################################

import os
import csv
import xlsxwriter

def creatWorkbook(path):
    """ Method to create Excel workbook from CSVs """
    
    os.chdir(path)
    workbook = xlsxwriter.Workbook('All_Org_Objects.xlsx')
    bold = workbook.add_format({'bold': True})
    for filename in os.listdir(path):
        if filename.endswith(".csv"):
            with open(filename) as csvfile:
                csv_reader = csv.reader(csvfile, delimiter=',')
                worksheet_name = filename.split('_objects_')[0][:31]
                worksheet = workbook.add_worksheet(worksheet_name)
                worksheet.write('A1', 'Object_Name', bold)
                worksheet.write('B1', 'Object_Type', bold)
                row = 1
                col = 0
                for field in csv_reader:
                    if field[0] == 'Object_Name' and field[1] == 'Object_Type':
                        pass
                    else:
                        worksheet.write(row, col, field[0])
                        worksheet.write(row, col + 1, field[1])
                        row += 1
    workbook.close()

# Main execution start here
    
if __name__ == '__main__':
    path = "/tmp/reports"
    creatWorkbook(path)
