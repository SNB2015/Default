##########################################################
#							 #
#    !!! Python script to create Excel workbook !!!      #
# 						         #		 
#  Function:                                             #
#     - This script creates an excel workbook fromi      #
#       CSV files  					 #	
#                                                        #
##########################################################

import os
import csv
import xlsxwriter

# Define variables
FIRST_NAME = 'First_Name'
LAST_NAME = 'Last_Name'
USERNAME = 'Username'
EMAIL = 'Email'
FIRST_NAME_INDEX = 0
LAST_NAME_INDEX = 1
USERNAME_INDEX = 2
EMAIL_INDEX = 3

def creatWorkbook(path):
    """ Method to create Excel workbook from CSVs """
        
    os.chdir(path)
    workbook = xlsxwriter.Workbook('AWX_Users.xlsx')
    bold = workbook.add_format({'bold': True})
    for filename in os.listdir(path):
        if filename.endswith(".csv"):
            with open(filename) as csvfile:
                csv_reader = csv.reader(csvfile, delimiter=',')
                worksheet_name = filename.split('.')[0][:31]
                worksheet = workbook.add_worksheet(worksheet_name)
                worksheet.write('A1', FIRST_NAME, bold)
                worksheet.write('B1', LAST_NAME, bold)
                worksheet.write('C1', USERNAME, bold)
                worksheet.write('D1', EMAIL, bold)
                row = 1
                col = 0
                for field in csv_reader:
                    if field[FIRST_NAME_INDEX] == 'First_Name' and field[LAST_NAME_INDEX] == 'Last_Name' and field[USERNAME_INDEX] == 'Username':
                        pass
                    else:
                        worksheet.write(row, col, field[FIRST_NAME_INDEX])
                        worksheet.write(row, col + 1, field[LAST_NAME_INDEX])
                        worksheet.write(row, col + 2, field[USERNAME_INDEX])
                        worksheet.write(row, col + 3, field[EMAIL_INDEX])
                        row += 1
    workbook.close()

# Main execution start here
    
if __name__ == '__main__':
    path = "/tmp/user_reports"
    creatWorkbook(path)
