﻿function shareInventory {
    param([string]$newServer)

   
        $Collection = Get-WmiObject -Query "Select * from win32_share" -Namespace root/cimv2 -ComputerName $newServer -ErrorAction Stop
        $arrShares = @()
        ForEach($oShare in $Collection)
        {  
            try 
            {
                if ($oShare.Name -match "home")
                { 
                    $sHomeUNC = "\\$newServer\" + $oShare.Name
                    write-host $sHomeUNC $oShare.Path
                    $oDrive = new-object system.io.driveinfo($oShare.Path)
                    $oDrive = $oDrive.Name.substring(0,2)
                    $oDrive = Get-WmiObject -Class Win32_logicaldisk -ComputerName $newServer -Filter "DeviceID = '$oDrive'" -ErrorAction Stop
                    $HShareClass = [PSCustomObject]@{
                        Share = $oShare.Name
                        FreeSpace = $oDrive.FreeSpace
                        LocalPath = $oShare.Path
                    }
                    $arrShares += $HShareClass
                    write-host "`t $arrShares.Share `t $arrShares.LocalPath `t $arrShares.FreeSpace"
                }
            }
            catch
            {
                $ErrorMessage = $_.Exception.Message
                write-host "Error while collecting information on shareinventory -> $ErrorMessage"
            }
        }
   
    return $arrShares
}

shareInventory AUMLWFSP01