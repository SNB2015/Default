﻿#requires -version 3

<#
.SYNOPSIS

  Search for a user in a domain

.DESCRIPTION

  Setup of Homedrive based on the user-id passed as input

  Requirements:
  Powershell
  Security privileges on all potential fileservers / Netapp filers sufficient to create folders and apply ACL changes
  Security privileges in Active Directory sufficient to update user account properties
  Security privileges on all Windows fileservers sufficient to create shares
  Local source files for each Region where centralized and randomized homefolder locations are used:
	  - Must be located in "E:\Homeshare\Sites\"  folder
	  - Must list full UNC path to every potential homefolder location for the region
	  - If centralized and randomized homefolders are not used, source file can be blank

  Actions:
  - Retrieve user account from Active Directory
  - Parse the Distinguished Name to determine the user's region and fileserver
  - Determine if regional Netapp or local fileserver should be used
  - Create a directory for the user on selected storage location
  - Windows server only - Share the directory
  - Copy  "NewUserTemplate" files to the new homedir

.PARAMETER sAMAccountName

  User ID for which Homedrive setup is requested

.OUTPUTS
  Log file stored in C:\Windows\NTRS

.NOTES
  Version:        6.0
  Author:         Aonkar Balkrushna Takalikar (ABT4)
  Creation Date:  
  Purpose/Change: 1.0 Initial script development
                  2.0 Removed RPC check in LegacyHomefolderPath and added extra check of Home Drive removal in finally block
                  3.0 Enabling exceution log email option
                  4.0 Change to fix isues with already existig Home Drive Folders
                  5.0 Change to fix issues with existing Home Drive Folders and check for its size before access provisioning
                  6.0 Change to fix issue with Home Folder which gets allocated in WindowsCommon function 

.EXAMPLE

PS F:\> .\Homeshare ISK3 
            or
PS F:\> .\Homeshare isk3

#>


[CmdletBinding()]

param(
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [ValidatePattern('[a-zA-Z0-9]')]
    [string]$sAMAccountName=$(throw "UserId is mandatory, Please provide a value.")
    )
     
    Write-Host "User Id is: $sAMAccountName"
    $pattern = '[^a-zA-Z0-9-$]'

    if ($sAMAccountName -match $pattern)
    {
        throw ('Invalid character in UserId: {0}' -f $matches[0])
    }
#############################_START_OF_FUNCTIONS_#############################

function GetADsPath {
    param([string]$sAMid,[string]$DNSdomain)

    $ldapdomain = ""
    $osplit = $DNSdomain.Split('.')
    ForEach ($dc in $osplit)
    {
        $ldapdomain = $ldapdomain + "DC=" + $dc + ","
    }
    $ldapdomain = $ldapdomain.Substring(0,$ldapdomain.Length -1)

    Log-Write -LogPath $LogPath -LineMsg ($ldapdomain)

    $iLoopSleep = 60
    $iLoopMax = 20
    $iLoopCount = 0
    $bLookupDone = $false

    Log-Write -LogPath $LogPath -LineMsg ("Querying " + $DNSdomain + " for user: " + $sAMid)

    While(($bLookupDone -eq $false) -and ($iLoopCount -le $iLoopMax))
    {
        $query = new-object system.directoryservices.directorysearcher
        $query.SearchRoot = "LDAP://$ldapdomain"
        $query.filter = "(&(objectClass=user)(sAMAccountName=$sAMid))"
        $query.SearchScope = "subtree"
        $result = $query.findAll()
        if($result.count -eq 0)
        {
            if($iLoopCount -eq $iLoopMax)
            {
                throw "User account does not exist, or has not# yet replicated (waited 20 minutes)"
            }
            else
            {
                Log-Write -LogPath $LogPath -LineMsg "$sAMid not found in the domain.  Sleeping 1 minute. Attempt# $iLoopCount of $iLoopMax"
                Start-Sleep -s $iLoopSleep
                $iLoopCount = $iLoopCount + 1 
            }
        }
        else
        {
            $bLookupDone = $true
        }
    }
        $sADSPath = $result.properties.Item("ADSPATH")
        return $sADSPath
    
}

function GetRegionOU {
    param([string]$sFQDN)

    $oSplit = $sRegionOU = ""
    $oSplit = $sFQDN.Split(',')

    ForEach ($element in $oSplit)
    {
        if($element -eq  "OU=Enterprise Support")
        {
            $index = $oSplit.IndexOf($element)
            $sRegionOU = $oSplit[$index -1]
        }
    }
    
    if ($sRegionOU -eq "")
    {
        Log-Write -LogPath $LogPath -LineMsg "No Regional OU found; User account exists in non-standard location: "
        Log-Write -LogPath $LogPath -LineMsg (" " + $sFQDN)
        Log-Write -LogPath $LogPath -LineMsg " "
        Log-Write -LogPath $LogPath -LineMsg "Move the user to a standard fileserver OU before trying again."
        throw "No Regional OU found"
    }
    else
    {
        $sRegionOU = $sRegionOU.Substring(3,$sRegionOU.Length-3)
    }

    return $sRegionOU.Trim()
}

function GetFileserverOU {
    param([string]$sFQDN)

    $oSplit = $sParentOU = ""
    $oSplit = $sFQDN.Split('=')
    $sParentOU = $oSplit[2].ToUpper().Substring(0,$oSplit[2].Length-3)
    return $sParentOU
}

function GetNAPHome {
    param([string]$Region,[string]$UserName)
    
    $RegionFileName = ""
    switch ($Region){
        "EMEA"  { $RegionFileName = "C:\Users\system-pag-idm\Homeshare\Sites\EMEA-Homeservers.txt"; break}
        "SG"    { $RegionFileName = "C:\Users\system-pag-idm\Homeshare\Sites\SG-Homeservers.txt"; break}
        "ID"    { $RegionFileName = "C:\Users\system-pag-idm\Homeshare\Sites\ID-Homeservers.txt"; break}
        default { $RegionFileName = "C:\Users\system-pag-idm\Homeshare\Sites\NA-Homeservers.txt"; break}
    }

    if (Test-path $RegionFileName -ErrorAction Stop)
    {
        $RegionFile = get-content -path $RegionFileName
        $arrUNC = @()
        ForEach ( $line in $RegionFile)
        {
          
            if (Test-path $line -ErrorAction Stop)
            {
                $path = ($line + "\" + $UserName)
                if(-Not (Test-path $path))
                {
                    $arrUNC += $line
                }   
                else
                {
                    Log-Write -LogPath $LogPath -LineMsg "Home Directory of $UserName already exist at path -> $line"
                    throw "Home Directory already exist path->$path"
                }             
            }
        }
    }
    else
    {
        Log-Write -LogPath $LogPath -LineMsg "Regional source file for $Region not found!"
        Log-Write -LogPath $LogPath -LineMsg "Quitting script, we can not proceed without regional source files!"
        Log-Write -LogPath $LogPath -LineMsg "Looking for this file: "
        Log-Write -LogPath $LogPath -LineMsg "$RegionFileName"
        throw "Regional source file not found"
    }
    

    return get-random $arrUNC

}

function LegacyHomefolderPath {
    param([string]$userADsPath,[string]$newServer)

    $newHome = ""
    $Fileserver = GetFileserverOU $userADsPath
    $windowsCheck = IsWindows $Fileserver
    if ($windowsCheck -match 'Access is denied')
    {
        throw "$windowsCheck"
    }
    elseif($windowsCheck -match 'False')
    {
        ##### Fileserver is a Netapp outside Chicago #####
        Log-Write -LogPath $LogPath -LineMsg "$Fileserver is running non-Windows OS"
        $newHome = "\\$Fileserver\Home$\$UserName"
    }
    else
    {
        ##### WINDOWS #####
        Log-Write -LogPath $LogPath -LineMsg "$Fileserver is running Windows OS"
        $newHome = "\\$newServer\$UserName" + "$"
    }

    return $newHome
}

function IsWindows {
    param([string]$server)

    try 
    {
        Get-WmiObject -Namespace root/cimv2 -ComputerName $server -Class Win32_OperatingSystem -ErrorAction Stop
    }
    catch
    {
        $ErrorMessage = $_.Exception.Message
        Log-Write -LogPath $LogPath -LineMsg "Error while running IsWindows -> $ErrorMessage"
        return ("" + $false + ", " + $ErrorMessage)
    }
    return $true
}

function Ping {
    param([string]$target)

    try
    {
      $colPings = get-wmiobject -query "Select * From Win32_PingStatus WHERE Address = '$target' " -Namespace root/cimv2 -ComputerName . -ErrorAction Stop
      ForEach( $objStatus in $colPings)
      {
        if ($objStatus.StatusCode -or ($objStatus.StatusCode -ne 0))
        {
            $Ping = $false
        }
        else
        {
            $Ping = $true
        }
      }

    }
    catch
    {
        $ErrorMessage = $_.Exception.Message
        Log-Write -LogPath $LogPath -LineMsg "Error while running Ping -> $ErrorMessage"
        return $false
    }
    return $Ping
}

###############################################################################
#### Windows tasks common to both CREATEs and MOVEs

function WindowsCommon {
    param([string]$newServer,[string]$UserName,[string]$domain)

    $arrShares = shareInventory $newServer
    $iMostFreeSpace = 0
    $sMostPath = $sMostShare = $currentVersion = ""
    Log-Write -LogPath $LogPath -LineMsg "Windows Fileserver legacy configuration"

    #Select the target drive based on:
    #1 - Does the volume contain a folder in the root named "home"
    #2 - The volume with the most free space
    for($i=0;$i -lt @($arrShares).count;$i++)
    {
        if($arrShares[$i].LocalPath.Length -gt 1)
        {
            if($arrShares[$i].FreeSpace -gt $iMostFreeSpace)
            {
                $iMostFreeSpace = $arrShares[$i].FreeSpace
                $sMostPath = $arrShares[$i].LocalPath
                $sMostShare = $arrShares[$i].Share
            }
            if(Test-Path ("\\$newServer\" + $arrShares[$i].Share + "\$UserName"))
            {   # to check it once again
                Log-Write -LogPath $LogPath -LineMsg ("ERROR: Network folder \\$newServer\$UserName$ already exists in path " +  $arrShares[$i].LocalPath )
                throw "Path already there"
            }

        }
    }

    
    if($sMostShare -eq "")
    {
    Log-Write -LogPath $LogPath -LineMsg "No Share selected under WindowsCommon function"
    throw " Share is empty "
    }
    

    $uncHome = "\\$newServer\$sMostShare\$UserName"
    Log-Write -LogPath $LogPath -LineMsg "Local home disk selected: $sMostPath"

    ### Stop if unshared folder already exists
    if(Test-path $uncHome -ErrorAction Stop)
    {
        Log-Write -LogPath $LogPath -LineMsg "ERROR: Path already exists: $uncHome"
        throw "Path already there"
    }
    else
    {
        Log-Write -LogPath $LogPath -LineMsg "Creating and ACL'ing path:  $uncHome"
        $dirStatus = subMkdir $uncHome
        if($dirStatus -match 'True') {
            Log-Write -LogPath $LogPath -LineMsg "Home Folder created now provisioning ACL"
            subCACLS $uncHome $domain $UserName
        }
        else {
            Log-Write -LogPath $LogPath -LineMsg "Home Directory already exist"
            throw  "Home Directory already exist"
        }
    }

    $localPath = ($sMostPath + "\" +  $UserName)
    $shareDesc = ""
    Log-Write -LogPath $LogPath -LineMsg "Folder created. Proceeding with Share creation: \\$newServer\$UserName$"

    $collection = get-wmiobject -query "Select * From Win32_OperatingSystem" -ComputerName $newServer -ErrorAction Stop
    ForEach( $OS in $collection)
    {
        [double]$currentVersion = ($OS.Version.Split(".")[0] + "." + $OS.Version.Split(".")[1])
    }
    Log-Write -LogPath $LogPath -LineMsg "OS Version of Windows File Server: $currentVersion"

    if ($currentVersion -ge 6.0)
    {
        newShareEveryoneFull $newServer ($UserName + "$") $localPath "EVERYONE" $shareDesc
    }
    else
    {
        $objWMI = [wmiClass]"\\$newServer\root\cimv2:Win32_share"   # also try select * from win32_share
        $FILE_SHARE = 0
        $MAX_CONN = $NULL
        $retVal = $objWMI.Create($localPath, ($UserName + "$"), $FILE_SHARE , $MAX_CONN, $shareDesc)
        shareStatus $retVal.returnValue
    }

    return $uncHome
    
}

function shareInventory {
    param([string]$newServer)

   
        $Collection = Get-WmiObject -Query "Select * from win32_share" -Namespace root/cimv2 -ComputerName $newServer -ErrorAction Stop
        $arrShares = @()
        ForEach($oShare in $Collection)
        {  
            try 
            {
                if ($oShare.Name -match "home")
                { 
                    $sHomeUNC = "\\$newServer\" + $oShare.Name
                    $oDrive = new-object system.io.driveinfo($oShare.Path)
                    $oDrive = $oDrive.Name.substring(0,2)
                    $oDrive = Get-WmiObject -Class Win32_logicaldisk -ComputerName $newServer -Filter "DeviceID = '$oDrive'" -ErrorAction Stop
                    $HShareClass = [PSCustomObject]@{
                        Share = $oShare.Name
                        FreeSpace = $oDrive.FreeSpace
                        LocalPath = $oShare.Path
                    }
                    $arrShares += $HShareClass
                    Log-Write -LogPath $LogPath -LineMsg "`t $arrShares.Share `t $arrShares.LocalPath `t $arrShares.FreeSpace"
                }
            }
            catch
            {
                $ErrorMessage = $_.Exception.Message
                Log-Write -LogPath $LogPath -LineMsg "Error while collecting information on shareinventory -> $ErrorMessage"
            }
        }
   
    return $arrShares
}

function subMkdir {
    param([string]$uncPath)
    try
    {
        Log-Write -LogPath $LogPath -LineMsg "Creating folder: $uncPath"
        New-Item -Path $uncPath -ItemType "directory" -ErrorAction Stop
    }

    catch
    {
        $ErrorMessage = $_.Exception.Message
        Log-Write -LogPath $LogPath -LineMsg "subMkdir $uncPath"
        throw ([String]$false + $ErrorMessage)
    }
    return $true
}

function subCACLS {
    param([string]$uncPath,[string]$domain,[string]$UserName)
    # The ACL change is wrapped inside a loop to wait for the new account to replicate
    $iLoopSleep = 60
    $iLoopMax = 20
    $iLoopCount = 0
    $bAclDone = $false
    $exeOUT = ""

    Log-Write -LogPath $LogPath -LineMsg "Granting access to user: $UserName"
    #If objFSO.FolderExists(strFolder) Then (this check can be applied)

    # Specify the group object 'sAMAccountName' to add to NTFS permission
    $addUser = "$domain\$UserName"

    # Configure the access object values
    $access    = [System.Security.AccessControl.AccessControlType]::Allow 
    $rights    = [System.Security.AccessControl.FileSystemRights]"FullControl"
    $inherit   = [System.Security.AccessControl.InheritanceFlags]"ContainerInherit,ObjectInherit"
    $propagate = [System.Security.AccessControl.PropagationFlags]::None

    While($bAclDone -eq $false -and ($iLoopCount -le $iLoopMax))
    {
        try
        { 
            $ace = New-Object System.Security.AccessControl.FileSystemAccessRule($addUser,$rights,$inherit,$propagate,$access) 

            # Retrieve the directory ACL and add a new ACL rule
            $acl = Get-Acl $uncPath -ErrorAction Stop
            $acl.AddAccessRule($ace) 
            $acl.SetAccessRuleProtection($false,$false) 
            Set-Acl $uncPath $acl -ErrorAction Stop
            $bAclDone = $true
            return
        }
        catch
        {
            $exeOUT = $_.Exception.Message
                    
        }

        Log-Write -LogPath $LogPath -LineMsg ("Error during ACL provisioning " + $exeOUT + " Possibly check for $UserName in $domain if present or not ")
        if($exeOUT -match "Some or all identity references could not be translated.")
        {
            if($iLoopCount -eq $iLoopMax)
            {
                Log-Write -LogPath $LogPath -LineMsg "ERROR: $exeOUT"
                Log-Write -LogPath $LogPath -LineMsg "User account does not exist, or has not yet replicated (waited 20 minutes)"
                throw "User account does not exist"
            }
            else
            {
                Log-Write -LogPath $LogPath -LineMsg "Sleeping 1 minute... Attempt# $iLoopCount of $iLoopMax"
                Start-Sleep -s $iLoopSleep
                
            }
        }
        else
        {
            throw $exeOUT
        }
        $iLoopCount = $iLoopCount + 1
    }
}

##############################################################################
#Found this code on the web to create Shares with perms using WMI
#Necessary to override the default Read only share perms with 2008

function newShareEveryoneFull {
    param([string]$strComputer,$shareName,$folderPath,$shareUser,$shareDesc)
        
        $refSID = ""
        $colWinAcct = get-wmiobject -query "Select * From Win32_Account WHERE Name = '$shareUser' " -Namespace root/cimv2 -ComputerName $strComputer -ErrorAction Stop
        $WinAcctCount =  $colWinAcct | measure

        If($WinAcctCount.count -lt 1)
        {
            Log-Write -LogPath $LogPath -LineMsg "User $shareUser Not Found - quitting"
            throw "share user not found"
        }
        ForEach($refItem in $colWinAcct)
        {
            $temprefSID = $refItem.SID
            $refSID = [WMI]"\\$strComputer\root\cimv2:win32_sid.sid='$temprefSID'"
        }
        $mc = [WMIClass] "\\$strComputer\root\cimv2:Win32_Trustee"
        $refTrustee = $mc.CreateInstance()
        $refTrustee | ForEach-Object {
            $_.Domain = $refSID.ReferencedDomainName
            $_.Name = $refSID.AccountName
            $_.SID = $refSID.BinaryRepresentation
            $_.SidLength = $refSID.SidLength
            $_.SIDString = $refSID.SID
        }
        
        $mc = [WMIClass] "\\$strComputer\root\cimv2:Win32_Ace"
        $ACE = $mc.CreateInstance()
        $ACE | ForEach-Object {
            $_.AccessMask = 2032127         #2032127 = "Full"; 1245631 = "Change"; 1179817 = "Read"
                                            #http://msdn.microsoft.com/library/default.asp?url=/library/en-us/wmisdk/wmi/win32_ace.asp
            $_.AceFlags = 3                 #what to apply ACE to inc inhehitance 3 - means files & folders get permssions & pass onto children
            $_.AceType = 0                  #0=allow access 1=deny access
            $_.Trustee = $refTrustee        #Set the Trustee (user) that this Access control Entry will refer to.
        }

        $SecDescClass = [WMIClass] "\\$strComputer\root\cimv2:Win32_SecurityDescriptor"
        $SecDesc = $SecDescClass.CreateInstance()                              #Create an instance of a Security Descriptor  ([wmiclass]'Win32_SecurityDescriptor').psbase.CreateInstance(), ([WMIClass] "Win32_ace").CreateInstance() 
        $SecDesc.DACL = [System.Management.ManagementBaseObject[]] ($ACE)      #$sd.DACL += @($ace.psobject.baseobject) # append 

        #Get the DACL property of the Security Descriptor object
        #Add the ACE to the Dynamic Access Control List on the object (an array) it will overwrite the old entries
        #unless you retreive & save 'em first & add them to a big array with the new entry as well as the old ones
        #Win32_Share Class http://msdn.microsoft.com/en-us/library/aa394435%28VS.85%29.aspx

        $Win32Share = [wmiclass] "\\$strComputer\root\cimv2:Win32_Share"
        $outParams = $Win32Share.Create($folderPath , $shareName , 0 , $maxallowed, $shareDesc, $null, $SecDesc)

        #Create the share with all the parameters we have set up
        $retVal = $outParams.returnValue
        shareStatus $retVal
}

function shareStatus {
    param([string]$retVal)
    
    if($retVal -eq "0" ) {Log-Write -LogPath $LogPath -LineMsg "Share created successfully" }
    if($retVal -ne 0 )
    {
        switch ($retVal) {
            "2"  {Log-Write -LogPath $LogPath -LineMsg "ERROR: $retVal - Access Denied"}
            "8"  {Log-Write -LogPath $LogPath -LineMsg "ERROR: $retVal - Unknown Failure"}
            "9"  {Log-Write -LogPath $LogPath -LineMsg "ERROR: $retVal - Invalid Name"}
            "10" {Log-Write -LogPath $LogPath -LineMsg "ERROR: $retVal - Invalid Level"}
            "21" {Log-Write -LogPath $LogPath -LineMsg "ERROR: $retVal - Invalid Parameter"}
            "22" {Log-Write -LogPath $LogPath -LineMsg "ERROR: $retVal - Duplicate Share"}
            "23" {Log-Write -LogPath $LogPath -LineMsg "ERROR: $retVal - Redirected Path"}
            "24" {Log-Write -LogPath $LogPath -LineMsg "ERROR: $retVal - Unknown Device or Directory"}
            "25" {Log-Write -LogPath $LogPath -LineMsg "ERROR: $retVal - Net Name Not Found"}

        }
        throw "Share creation failed"
    }
}

function usage {
    param([string]$UserName)
    Log-Write -LogPath $LogPath -LineMsg "`tUSAGE:"
    Log-Write -LogPath $LogPath -LineMsg ($MyInvocation.MyCommand.Name + "$UserName")
    Log-Write -LogPath $LogPath -LineMsg "This script only has one mode: Create a homefolder for the specified user."
    Log-Write -LogPath $LogPath -LineMsg "The user account must exit in a fileserver OU in Active Directory."
    Log-Write -LogPath $LogPath -LineMsg "The script will parse the path where the account exists to"
    Log-Write -LogPath $LogPath -LineMsg "determine where to create the homefolder"
}

function homeDriveCheckWindows {
    param([string]$ErrorMessage,[string]$UserName,[string]$domain)
    $Execution = ""

try {    
    ### Extract the Home Drive Path from Errormessage
        $homeDrivePath = $ErrorMessage.Split('->')[2]
        if((Get-ChildItem $homeDrivePath -Recurse -Directory |  Measure-Object | select -Expand Count) -gt 0) {
            $folderSize = Get-Childitem -Path $homeDrivePath -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue
            Log-Write -LogPath $LogPath -LineMsg ("Home Drive subfolders are present and folder size in MB is " + $folderSize.Sum / 1MB)
                        
            ### Check for other AD attributes if set
            $objUser = [ADSI]"WinNT://$domain/$UserName,user"
            if(!([string]::IsNullOrEmpty($objUser.HomeDirectory)) -and (![string]::IsNullOrEmpty($objUser.HomeDirDrive))) {
                $Execution = "Success" 
                Log-Write -LogPath $LogPath -LineMsg "Home Drive attributes are already set with following values" 
                Log-Write -LogPath $LogPath -LineMsg ("Home Directory ->" + $objUser.HomeDirectory)    
                Log-Write -LogPath $LogPath -LineMsg ("Home Drive ->" +  $objUser.HomeDirDrive)   
            }
            else {
                if($homeDrivePath -match $UserName -and ($folderSize.Sum / 1MB) -lt 1 ) {
                    Log-Write -LogPath $LogPath -LineMsg "Home Drive attributes are empty hence giving access and assigning values $homeDrivePath as directory and F as drive" 
                    subCACLS $homeDrivePath $domain $UserName
                    Log-Write -LogPath $LogPath -LineMsg "Home Drive access provisioned to Lan ID $UserName"                  
                    $objUser.put("HomeDirectory",$homeDrivePath)
                    $objUser.put("HomeDirDrive","F:")
                    $objUser.SetInfo()
                    Log-Write -LogPath $LogPath -LineMsg "Home Drive attributes value assigned"
                    $Execution = "Success"
                }
                else {
                    Log-Write -LogPath $LogPath -LineMsg "Home Drive Folder $homeDrivePath didn't match the the new User ID or Folder size is greater then 1 MB"
                    $Execution = "Failure" 
                }
            }
            
        }      
        else {
            Log-Write -LogPath $LogPath -LineMsg "Home Drive subfolders are not present"
            $Execution = "Failure"    
        }
}
catch {
    $ErrorMessage = $_.Exception.Message
    Log-Write -LogPath $LogPath -LineMsg "Error -> $ErrorMessage"
    $Execution = "Failure"
}
    return $Execution
}

function homeDriveCheckNetapp {
    param([string]$ErrorMessage,[string]$UserName,[string]$domain)
    $Execution = ""

try {
    ### Extract the Home Drive Path from Errormessage
    $homeDrivePath = $ErrorMessage.Split()[-3]
    if((Get-ChildItem $homeDrivePath -Recurse -Directory |  Measure-Object | select -Expand Count) -gt 0) {
        $folderSize = Get-Childitem -Path $homeDrivePath -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue
        Log-Write -LogPath $LogPath -LineMsg ("Home Drive subfolders are present and folder size in MB is " + $folderSize.Sum / 1MB)

        ### Check for other AD attributes if set
        $objUser = [ADSI]"WinNT://$domain/$UserName,user"
        if(!([string]::IsNullOrEmpty($objUser.HomeDirectory)) -and (![string]::IsNullOrEmpty($objUser.HomeDirDrive))) {
            $Execution = "Success" 
            Log-Write -LogPath $LogPath -LineMsg "Home Drive attributes are already set with following values" 
            Log-Write -LogPath $LogPath -LineMsg ("Home Directory ->" + $objUser.HomeDirectory)    
            Log-Write -LogPath $LogPath -LineMsg ("Home Drive ->" +  $objUser.HomeDirDrive)   
        }
        else {
             if($homeDrivePath -match $UserName -and ($folderSize.Sum / 1MB) -lt 1 ) {
                Log-Write -LogPath $LogPath -LineMsg "Home Drive attributes are empty hence giving access and assigning values $homeDrivePath as directory and F as drive"
                subCACLS $homeDrivePath $domain $UserName
                Log-Write -LogPath $LogPath -LineMsg "Home Drive access provisioned to Lan ID $UserName"
                $objUser.put("HomeDirectory",$homeDrivePath)
                $objUser.put("HomeDirDrive","F:")
                $objUser.SetInfo()
                Log-Write -LogPath $LogPath -LineMsg "Home Drive attributes value assigned"
                $Execution = "Success"
                }
             else {
                Log-Write -LogPath $LogPath -LineMsg "Home Drive Folder $homeDrivePath didn't match the the new User ID or Folder size is greater then 1 MB"
                $Execution = "Failure" 
             }
        }
    }      
    else {
        Log-Write -LogPath $LogPath -LineMsg "Home Drive subfolders are not present"
        $Execution = "Failure"    
    }
}
catch {
    $ErrorMessage = $_.Exception.Message
    Log-Write -LogPath $LogPath -LineMsg "Error -> $ErrorMessage"
    $Execution = "Failure"
}
    return $Execution

}

function CopyTemplate {
    param([string]$newServer,[string]$uncHome,[string]$DNSdomain)
    ### Copy new homefolder template folders and files to home directory

    ### This path works in ENT domain but has been removed for ENTDEV hence creating a local path of it 
    #$uncTemplate = "\\$DNSdomain" + "\serverteam\Data\FS\NewUserTemplate"
    #######
    $uncTemplate = "E:\Home\Test_Home_Folders\NewUserTemplate"

    Log-Write -LogPath $LogPath -LineMsg "Copying template folders from $uncTemplate"

    if (Test-path $uncTemplate -ErrorAction Stop)
    {
        $copySource = $uncTemplate + "\*"
        $copyDest = $uncHome + "\"
        Copy-Item $copySource -Destination $copyDest -Recurse
    }
    else
    {
        Log-Write -LogPath $LogPath -LineMsg "Template could not be copied because it does not exist: $uncTemplate"
    }

}

function updateAccount {
    param([string]$userName,[string]$domain,[string]$userHome)
    
        $iRetry = 1
	    $maxRetry = 3
	    $bDone  = $false

        Log-Write -LogPath $LogPath -LineMsg "Updating HomeDirectory and HomeDirDrive"
        while($bDone -eq $false -and $iRetry -le $maxRetry )
        {
            Log-Write -LogPath $LogPath -LineMsg "GetUser attempt: $iRetry"
            $objUser = [ADSI]"WinNT://$domain/$userName,user"
            if(!$objUser.Name)
            {
                Log-Write -LogPath $LogPath -LineMsg "Error retrieving user account from Active directory"
                Log-Write -LogPath $LogPath -LineMsg (" " + $objUser)
                $exeNLT = NLTEST /sc_query:$domain
                while ($exeNLT.Status -eq 0)
                {
                    Start-Sleep -Milliseconds 100
                }
               
                Log-Write -LogPath $LogPath -LineMsg (" " + $exeNLT)
                Start-Sleep -Milliseconds 10000
                if($iRetry -eq $maxRetry)
                {
                        throw ""
                }
            }
            else
            {
                try
                {
                    $objUser.put("HomeDirectory",$userHome)
                    $objUser.put("HomeDirDrive","F:")
                    $objUser.SetInfo()
                    $bDone = $true
                    Log-Write -LogPath $LogPath -LineMsg "Account update success"
                }
                catch
                {
                    Log-Write -LogPath $LogPath -LineMsg "Error updating user account attribute for home directory path."
                    Log-Write -LogPath $LogPath -LineMsg (" " + $objUser)
                    if($iRetry -eq $maxRetry)
                    {
                        throw ""
                    }
                }
            }
            $iRetry = $iRetry + 1
        }
        
}

################################_START_OF_MAIN_#################################
try{

#Global variables
$src_dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$datestring = (Get-Date).ToString("s").Replace(":","-")
$Script_Start = Get-Date
$DNSdomain = [System.DirectoryServices.ActiveDirectory.Domain]::GetComputerDomain().name
$domain = ($DNSdomain.split("."))[0]
$uncHome = $LOG_FILENAME = $Region = $NewHomeFolderPath = $ErrorMessage = $Execution = $dirStatus = $ShareAllocation = ""



#region import_external_scripts
    . "$src_dir\Logging.ps1"

#This array is defined by the regional OUs in Active Directory.
#Do not add members here if there is not an OU under "Enterprise Support" that matches the name.
    $dict = @{}
    $dict.Add('CHICAGO','NA')
    $dict.Add('ARIZONA','NA')
    $dict.Add('CALIFORNIA','NA')
    $dict.Add('CONNECTICUT','NA')
    $dict.Add('FLORIDA','NA')
    $dict.Add('NORTHEAST','NA')
    $dict.Add('NTVI','NA')
    $dict.Add('ONTARIO','NA')
    $dict.Add('TEXAS','NA')
    $dict.Add('ENGLAND','EMEA')
    $dict.Add('GUERNSEY','EMEA')
    $dict.Add('IRELAND','EMEA')
    $dict.Add('LUXEMBOURG','EMEA')
    $dict.Add('SINGAPORE','SG')
    $dict.Add('INDIA','ID')

    $UserName = $sAMAccountName.ToLower();
    if( $UserName -match ' ') 
    {
        throw "Username should not contain space"
    }

    $LOG_FILENAME = "HomeDriveSetup-$UserName-$datestring.log"
    Log-Start -LogPath $LogPath
    Log-Write -LogPath $LogPath -LineMsg "Username:    $UserName"

    $userADsPath = GetADsPath $UserName $DNSdomain
    
    ## USER ADs path found
    $Execution = "Success"
    
} #Try ends here
catch
{
    $ErrorMessage = $_.Exception.Message
    Log-Write -LogPath $LogPath -LineMsg "Error -> $ErrorMessage"
    if($ErrorMessage -match "Home Directory already exist") {
       $Execution = homeDriveCheckWindows $ErrorMessage $UserName $domain       
    }
    elseif($ErrorMessage -match "FalseAn item with the specified name" -and $ErrorMessage -match "already exists") {
       $Execution = homeDriveCheckNetapp $ErrorMessage $UserName $domain
    }
    else {
       $Execution = "Failure"
    }
     
}
Finally
{   
    try
    {      
        #Delete the Homedrive folder if it cause issue while setting it up
        if($Execution -eq "Success")
        {
            write-host "Search completed SUCCESSFULLY"
        }
        else 
        {
            write-host "Search failed, user not found"
            $Execution = "Failure"
            
         }
    }
    catch
    {
        $ErrorMessage = $_.Exception.Message
    }
    Log-Finish -NoExit true -ScriptStartDate $Script_Start -LogPath $LogPath

    write-host ($Execution + " " + $ErrorMessage)

    if($Execution -eq "Failure" -or (-not $Execution))
    {
        #Log-Email -LogPath ($LOG_PATH + $LOG_FILENAME) -EmailFrom "DoNotReply@ntrs.com" -EmailTo $EmailTo -EmailSubject "$UserName Home-Drive Setup in $domain, Status -> $Execution"
    }
    
}

################################_END_OF_MAIN_#################################




