﻿
function subMkdir {
    param([string]$uncPath)
    try
    {
        write-host "Creating folder: $uncPath"
        
    }

    catch
    {
        $ErrorMessage = $_.Exception.Message
        write-host "subMkdir $uncPath $ErrorMessage"
        
    }
    return $true
}

function subCACLS {
    param([string]$uncPath,[string]$UserName)
    write-host "subacl  $uncPath"
}


function shareInventory {
    param([string]$newServer)

   
        $Collection = Get-WmiObject -Query "Select * from win32_share" -Namespace root/cimv2 -ComputerName $newServer -ErrorAction Stop
        $arrShares = @()
        ForEach($oShare in $Collection)
        {  
            try 
            {
                if ($oShare.Name -match "home")
                { 
                    $sHomeUNC = "\\$newServer\" + $oShare.Name
                    write-host $sHomeUNC $oShare.Path
                    $oDrive = new-object system.io.driveinfo($oShare.Path)
                    $oDrive = $oDrive.Name.substring(0,2)
                    $oDrive = Get-WmiObject -Class Win32_logicaldisk -ComputerName $newServer -Filter "DeviceID = '$oDrive'" -ErrorAction Stop
                    $HShareClass = [PSCustomObject]@{
                        Share = $oShare.Name
                        FreeSpace = $oDrive.FreeSpace
                        LocalPath = $oShare.Path
                    }
                    $arrShares += $HShareClass
                    write-host "`t $arrShares.Share `t $arrShares.LocalPath `t $arrShares.FreeSpace"
                }
            }
            catch
            {
                $ErrorMessage = $_.Exception.Message
                write-host "Error while collecting information on shareinventory -> $ErrorMessage"
            }
        }
   
    return $arrShares
}


function WindowsCommon {
    param([string]$newServer,[string]$UserName)

    $arrShares = shareInventory $newServer
    $iMostFreeSpace = 0
    $sMostPath = $sMostShare = $currentVersion = ""
    write-host "Windows Fileserver legacy configuration"

    #Select the target drive based on:
    #1 - Does the volume contain a folder in the root named "home"
    #2 - The volume with the most free space
    for($i=0;$i -lt @($arrShares).count;$i++)
    {
        if($arrShares[$i].LocalPath.Length -gt 1)
        {
            if($arrShares[$i].FreeSpace -gt $iMostFreeSpace)
            {
                $iMostFreeSpace = $arrShares[$i].FreeSpace
                $sMostPath = $arrShares[$i].LocalPath
                $sMostShare = $arrShares[$i].Share
            }
            if(Test-Path ("\\$newServer\" + $arrShares[$i].Share + "\$UserName"))
            {   # to check it once again
                write-host ("ERROR: Network folder \\$newServer\$UserName$ already exists in path " +  $arrShares[$i].LocalPath )
                write-host "Path already there"
            }

        }
    }

    
    if($sMostShare -eq "")
    {
    write-host "No Share selected under WindowsCommon function"
    write-host " Share is empty "
    }
    

    $uncHome = "\\$newServer\$sMostShare\$UserName"
    write-host "Local home disk selected: $sMostPath"

    ### Stop if unshared folder already exists
    if(Test-path $uncHome -ErrorAction Stop)
    {
        write-host "ERROR: Path already exists: $uncHome"
        write-host "Path already there"
    }
    else
    {
        write-host "Creating and ACL'ing path:  $uncHome"
        
        
    }

     subMkdir $uncHome
        
     subCACLS $uncHome $UserName
        

    return $uncHome
    
}

#$UserName = "kzs6"

    #$folderpath = WindowsCommon "AUMLWFSP01" $UserName 
#$arrShares.count

#write-host $folderpath
write-host "starting"
$arrShares = shareInventory HKHKWFSP01
