
$LOG_FOLDER = Get-Date -UFormat "%b-%Y"
$LOG_FOLDER = $LOG_FOLDER.ToString()
$LOG_PATH = "$src_dir\Logs\$LOG_FOLDER\"
$EmailTo = @("isk3@ntrs.com","hvs2@ntrs.com","pl112@ntrs.com")

Function Log-Start{
  <#
  .SYNOPSIS
    Creates log file

  .DESCRIPTION
    Creates log file with path and name that is passed. Checks if log file exists use it, if not create a new one.
    Once created, writes initial logging data

  .PARAMETER LogPath
    Path of where log is to be created. Example: C:\Windows\Temp

  .PARAMETER LogName
    Name of log file to be created. Example: Test_Script.log
      
  .PARAMETER ScriptVersion
     Version of the running script which will be written in the log. Example: 1.0

 .PARAMETER ScriptName
     Name of the script . Example: VMAXCreateDataLun.ps1

  .INPUTS
    Parameters above

  .OUTPUTS
    Log file created

  .NOTES
    Version:        1.0
    Author:         Inderjeet Singh Khalsa
    Creation Date:  11-06-2019
    Purpose/Change: Initial function development

  .EXAMPLE
    Log-Start -LogPath "C:\Windows\Temp" -LogName "Test_Script.log" -ScriptVersion "1.0"
  #>
    
  [CmdletBinding()]
  
  Param (
  	[Parameter(Mandatory=$false)][string]$LogPath,
	[Parameter(Mandatory=$false)][string]$LogName,
	[Parameter(Mandatory=$false)][string]$ScriptVersion,
	[Parameter(Mandatory=$false)][string]$ScriptName

	)

   

    if( -Not $LogPath  ){
        
        $LogPath =  $LOG_PATH
        
    }

    if( -Not $LogName  ){
        $LogName = $LOG_FILENAME
    }

    if( -Not $ScriptVersion  ){
        $ScriptVersion = $SCRIPT_VERSION
    }

    if( -Not $ScriptName  ){
        $ScriptName = $SCRIPT_NAME
    }
    
     $sFullPath = $LogPath + $LogName
     
    
    #Creat Log Directory if missing
    if(-not (Test-Path -Path $LogPath)){
        New-Item -Path $LogPath -ItemType "directory" -ErrorAction Stop
    }

    #Check if file exists
    If((Test-Path -Path $sFullPath)){
     	Add-Content -Path $sFullPath -Value "***************************************************************************************************"
    	Add-Content -Path $sFullPath -Value "Started processing at [$([DateTime]::Now)]."
    	Add-Content -Path $sFullPath -Value "Running script [$ScriptName] version [$ScriptVersion]."
    	Add-Content -Path $sFullPath -Value "***************************************************************************************************"
    	Add-Content -Path $sFullPath -Value ""
    }else{
    
    	#Create file and start logging
    	New-Item -Path $LogPath -Name $LogName -ItemType File
    
    	Add-Content -Path $sFullPath -Value "***************************************************************************************************"
    	Add-Content -Path $sFullPath -Value "Started processing at [$([DateTime]::Now)]."
    	Add-Content -Path $sFullPath -Value "Running script [$ScriptName] version [$ScriptVersion]."
    	Add-Content -Path $sFullPath -Value "***************************************************************************************************"
    	Add-Content -Path $sFullPath -Value ""
	}
}
Function Log-Write{
  <#
  .SYNOPSIS
    Writes to a log file

  .DESCRIPTION
    Appends a new line to the end of the specified log file
  
  .PARAMETER LogPath
    Mandatory. Full path of the log file you want to write to. Example: C:\Windows\Temp\Test_Script.log
  
  .PARAMETER LineValue
    Mandatory. The string that you want to write to the log
      
  .INPUTS
    Parameters above

  .OUTPUTS
    None

  .NOTES
    Version:        1.0
    Author:         Inderjeet Singh Khalsa
    Creation Date:  11-06-2019
    Purpose/Change: Initial function development
	
  .EXAMPLE
    Log-Write -LogPath "C:\Windows\Temp\Test_Script.log" -LineValue "This is a new line which I am appending to the end of the log file."
  #>
  
  [CmdletBinding()]
  
    Param (
  	[Parameter(Mandatory=$false)][string]$LogPath,
	[Parameter(Mandatory=$false)][string]$LogName,
	[Parameter(Mandatory=$true)][string]$LineMsg
	)
    <#
    if( -Not $LogPath  ){
        $LogPath = $SRC_DIR
    }
 
    if( -Not $LogName  ){
        $LogName = $LOG_FILENAME
    }
    #>

    
    if( -Not $LogPath  ){
        
        $LogPath =  $LOG_PATH
        
    }

    if( -Not $LogName  ){
        $LogName = $LOG_FILENAME
    }



 

     $sFullPath = $LogPath + $LogName
    


   # $LineDate = "$((Get-Date -Format dd.MM.yyyy)) $((Get-Date -DisplayHint time  -Format HH:mm:ss)):"

    $msgWrite = $LineMsg

	#$msgWrite = $LineDate + " " + $LineMsg
	
	Add-Content -Path $sFullPath -Value $msgWrite

}
Function Log-Error{
  <#
  .SYNOPSIS
    Writes an error to a log file

  .DESCRIPTION
    Writes the passed error to a new line at the end of the specified log file
  
  .PARAMETER LogPath
    Mandatory. Full path of the log file you want to write to. Example: C:\Windows\Temp\Test_Script.log
  
  .PARAMETER ErrorDesc
    Mandatory. The description of the error you want to pass (use $_.Exception)
  
  .PARAMETER ExitGracefully
    Mandatory. Boolean. If set to True, runs Log-Finish and then exits script

  .INPUTS
    Parameters above

  .OUTPUTS
    None

  .NOTES
    Version:        1.0
    Author:         Inderjeet Singh Khalsa
    Creation Date:  11-06-2019
    Purpose/Change: Initial function development

  .EXAMPLE
    Log-Error -LogPath "C:\Windows\Temp\Test_Script.log" -ErrorDesc $_.Exception -ExitGracefully $True
  #>
  
  [CmdletBinding()]
  
  Param (
  	[Parameter(Mandatory=$false)][string]$LogPath,
  	[Parameter(Mandatory=$true)][string]$ErrorDesc,
	[Parameter(Mandatory=$false)][string]$LogName,
	[Parameter(Mandatory=$false)][boolean]$ExitGracefully
	)


    if( -Not $LogPath  ){
        
        $LogPath =  $LOG_PATH
        
    }

    if( -Not $LogName  ){
        $LogName = $LOG_FILENAME
    }

    
	#$LogPath = $LogPath + '\logs\'
    $sFullPath = $LogPath + $LogName 

    Add-Content -Path $sFullPath -Value "Error: An error has occurred [$ErrorDesc]."
   
    #If $ExitGracefully = True then run Log-Finish and exit script
    If ($ExitGracefully -eq $True){
      Log-Finish -LogPath $LogPath
      Break
    }
}
Function Log-Finish{
  <#
  .SYNOPSIS
    Write closing logging data & exit

  .DESCRIPTION
    Writes finishing logging data to specified log and then exits the calling script
  
  .PARAMETER LogPath
    Mandatory. Full path of the log file you want to write finishing data to. Example: C:\Windows\Temp\Test_Script.log

  .PARAMETER NoExit
    Optional. If this is set to True, then the function will not exit the calling script, so that further execution can occur
  
  .INPUTS
    Parameters above

  .OUTPUTS
    None

  .NOTES
    Version:        1.0
    Author:         Inderjeet Singh Khalsa
    Creation Date:  11-06-2019
    Purpose/Change: Initial function development
    
  .EXAMPLE
    Log-Finish -LogPath "C:\Windows\Temp\Test_Script.log"

.EXAMPLE
    Log-Finish -LogPath "C:\Windows\Temp\Test_Script.log" -NoExit $True
  #>
  
  [CmdletBinding()]
  
  Param ([Parameter(Mandatory=$false)][string]$LogPath,
  		[Parameter(Mandatory=$false)][string]$LogName,
  		[Parameter(Mandatory=$false)][string]$NoExit,
		[Parameter(Mandatory=$false)][DateTime]$ScriptStartDate)
  
  Process{
    <#
     if( -Not $LogPath  ){
        $LogPath = $SRC_DIR
    }
 
    if( -Not $LogName  ){
        $LogName = $LOG_FILENAME
    }
  	$LogPath = $LogPath + '\logs\'
    $sFullPath = $LogPath + $LogName
    Write-Host "LogFinish $ScriptStartDate"
    #>
       
    if( -Not $LogPath  ){
        
        $LogPath =  $LOG_PATH
        
    }

    if( -Not $LogName  ){
        $LogName = $LOG_FILENAME
    }


     $sFullPath = $LogPath + $LogName

    if( $ScriptStartDate -ne $null ) {
        $Script_End = ((Get-Date) - $ScriptStartDate).TotalSeconds
        $TimeSpan = New-TimeSpan -Seconds $Script_End
        $Duration = '{0:00}:{1:00}:{2:00}' -f $TimeSpan.Hours,$TimeSpan.Minutes,$TimeSpan.Seconds
    }
		
    Add-Content -Path $sFullPath -Value ""
    Add-Content -Path $sFullPath -Value "***************************************************************************************************"
    Add-Content -Path $sFullPath -Value "Finished processing at [$([DateTime]::Now)]. Script Total Duration: $Duration"
    Add-Content -Path $sFullPath -Value "***************************************************************************************************"
   
    #Exit calling script if NoExit has not been specified or is set to False
    If(!($NoExit) -or ($NoExit -eq $False)){
      $ErrorActionPreference = "Stop"
      Exit
    }    
  }
}
Function Log-Email{
  <#
  .SYNOPSIS
    Emails log file to list of recipients

  .DESCRIPTION
    Emails the contents of the specified log file to a list of recipients
  
  .PARAMETER LogPath
    Mandatory. Full path of the log file you want to email. Example: C:\Windows\Temp\Test_Script.log
  
  .PARAMETER EmailFrom
    Mandatory. The email addresses of who you want to send the email from. Example: "admin@9to5IT.com"

  .PARAMETER EmailTo
    Mandatory. The email addresses of where to send the email to. Seperate multiple emails by ",". Example: "admin@9to5IT.com, test@test.com"
  
  .PARAMETER EmailSubject
    Mandatory. The subject of the email you want to send. Example: "Cool Script - [" + (Get-Date).ToShortDateString() + "]"

  .INPUTS
    Parameters above

  .OUTPUTS
    Email sent to the list of addresses specified

  .NOTES
    Version:        2.0
    Author:         Inderjeet Singh Khalsa
    Creation Date:  11-06-2019
    Purpose/Change: 1.0 Initial function development
                    2.0 Changed EmailTo type from string to string array
	
  .EXAMPLE
    Log-Email -LogPath "C:\Windows\Temp\Test_Script.log" -EmailFrom "admin@9to5IT.com" -EmailTo "admin@9to5IT.com, test@test.com" -EmailSubject "Cool Script - [" + (Get-Date).ToShortDateString() + "]"
  #>
  
  [CmdletBinding()]
  
  Param ([Parameter(Mandatory=$true)][string]$LogPath, [Parameter(Mandatory=$true)][string]$EmailFrom, [Parameter(Mandatory=$true)][string[]]$EmailTo, [Parameter(Mandatory=$true)][string]$EmailSubject)
  
  Process{
    Try{
       $sBody = "<p> Please find IDM Home Drive Creation logs at following path :- $LogPath  <br/></p>" + "<b> If log file is not attached, Please check manually </b>"
           
      #Create SMTP object and send email
      $sSmtpServer = "mail.ntrs.com"
  #    $oSmtp = new-object Net.Mail.SmtpClient($sSmtpServer)
  #    $oSmtp.Send($EmailFrom, $EmailTo, $EmailSubject, $sBody)
      Send-MailMessage -From $EmailFrom -To $EmailTo -Subject $EmailSubject -Body $sBody -BodyAsHtml -Attachments $LogPath  -dno onSuccess, onFailure -SmtpServer $sSmtpServer
      Exit 0
    }
    
    Catch{
      Exit 1
    } 
  }
}


Function Log-Error-StdOutput{
  <#
  .SYNOPSIS
    Writes an error to a Std output 

  .DESCRIPTION
    Writes an error to a Std output 
   
  .PARAMETER ErrorDesc
    Mandatory. The description of the error
  
  .INPUTS
    Parameters above

  .OUTPUTS
    None

  .NOTES
    Version:        1.0
    Author:         Inderjeet Singh Khalsa
    Creation Date:  11-06-2019
    Purpose/Change: Initial function development

  .EXAMPLE
    Log-Error "Error Formating the drives"
  #>
  
  [CmdletBinding()]
  
  Param (
   [Parameter(Mandatory=$false)][string]$LogPath,
   [Parameter(Mandatory=$true)][string]$ErrorDesc
	)  
    $SCRIPT_ERROR_BEGIN = "%%Start";
    $SCRIPT_ERROR_END = "%%End";
    
    Write-Host "$SCRIPT_ERROR_BEGIN $ErrorDesc $SCRIPT_ERROR_END"
    Log-Write -LogPath $LogPath  -LineMsg $ErrorDesc
    Log-Finish -NoExit false -ScriptStartDate $Script_Start -LogPath $LogPath

    
}



